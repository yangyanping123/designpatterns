<?php

namespace DesignPatterns\More\ServiceLocator;

class LogService
{
}
