<?php

namespace DesignPatterns\Creational\Builder\Parts;

class Car extends Vehicle
{
}
