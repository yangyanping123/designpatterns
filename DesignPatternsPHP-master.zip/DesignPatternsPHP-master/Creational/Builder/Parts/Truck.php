<?php

namespace DesignPatterns\Creational\Builder\Parts;

class Truck extends Vehicle
{
}
